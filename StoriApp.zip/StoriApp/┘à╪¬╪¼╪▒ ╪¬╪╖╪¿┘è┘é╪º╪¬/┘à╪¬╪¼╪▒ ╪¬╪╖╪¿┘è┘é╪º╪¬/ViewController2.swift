//
//  ViewController2.swift
//  متجر تطبيقات
//
//  Created by Ahmed Salah on 4/22/20.
//  Copyright © 2020 Ahmed Salah. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var UDID: UILabel!
    @IBOutlet weak var iDeV: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(UIDevice.current.model)
        print(UIDevice.current.identifierForVendor!)
        let dd = UIDevice.current.model as String
        iDeV.text! = dd
        
        ///////////////
        
        let deviceUUID: String = UIDevice.current.identifierForVendor!.uuidString
        UDID.text! = deviceUUID
    }
    
}
