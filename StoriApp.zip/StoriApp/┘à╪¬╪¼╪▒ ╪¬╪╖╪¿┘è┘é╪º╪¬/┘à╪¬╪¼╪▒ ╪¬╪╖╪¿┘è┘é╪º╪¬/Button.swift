//
//  Button.swift
//  متجر تطبيقات
//
//  Created by Ahmed Salah on 4/22/20.
//  Copyright © 2020 Ahmed Salah. All rights reserved.
//

import AVKit
class Button : UIButton{
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = 10
        
        
    }
 
}
